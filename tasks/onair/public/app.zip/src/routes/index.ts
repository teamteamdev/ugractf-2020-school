import guests from './guests';
import users from './users';

export default {guests, users};
